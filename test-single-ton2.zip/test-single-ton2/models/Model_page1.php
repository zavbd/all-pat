<?php
require_once('Model.php');
class Model_page1 extends Model
{
	protected $params;
	public $params_next;
	protected $headers;
	public $records;
	public function className()
	{
		return __CLASS__;
	}
	public function output()
	{
		$this->params[] = "1";
		$this->params[] = "2";
		$this->params[] = "3";
		$this->setHeader();
		$this->setRecords();
		//echo $this->name;exit;
		//$this->setOther();
		//$this->getTestObject1();
	}
	
	public function setHeader()
	{
		$this->params_next=array('a'=>1,'b'=>2);
		$this->headers=array('col1'=>'1stcol','col2'=>'2ndcol','col3'=>'3rdcol');
	}
	public function setRecords()
	{
		$this->records=array(
			array('col1'=>'val1','col2'=>'test1','col3'=>'last1'),
			array('col1'=>'val2','col2'=>'test2','col3'=>'last2'),
			array('col1'=>'val3','col2'=>'test3','col3'=>'last3')
		);
	}
	/*
	public function getTestObject1()
	{
		return new TestObject1();
	}*/
	public function acceptVisitor($download_visitor)
	{
		$download_visitor->visit($this);
		echo 'visitor has been finished his job<hr>';
		print_r($this->records);exit;
	}
}
/*
class TestObject1
{
	public function __construct()
	{
		$this->test();
	}
	
	public function test()
	{
		echo 'inside TestObject1 test function<hr>';
		print_r(Registry::ins()->get('model1'));
		unset(Registry::ins()->get('model1')->params_next);
		print_r(Registry::ins()->get('model1')->params);
		
		//print_r(RegisterGlobal::ins()->model->params);exit;
	}
}*/
?>