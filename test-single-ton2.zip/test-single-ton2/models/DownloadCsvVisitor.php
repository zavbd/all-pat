<?php
class DownloadCsvVisitor
{
	public function visit($visited)
	{
		echo 'inside visitor class<hr>';
		//print_r($visited);
		print_r($visited->records);
		$visited->records[]=array('col1'=>'visi_val3','col2'=>'visi_test3','col3'=>'visi_last3');
		//exit;
	}
}
?>