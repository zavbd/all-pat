<?php
class Registry
{
	private static $instance;
	protected static $store = array();
	private function __construct()
	{
	}
	public function isValid($key)
	{
		return array_key_exists($key, Registry::$store);
	}
	public static function ins()
	{
		if(self::$instance==null)
		{
			echo 'initializing<hr>';
			self::$instance=new Registry();
		}
		return self::$instance;
	}
	
	public function get($key)
	{
		if(array_key_exists($key, Registry::$store))
		{
			return Registry::$store[$key];
		}
	}
	
	public function set($key, $obj)
	{
		Registry::$store[$key] = $obj;
	}
}
?>