<?php
require_once('Model.php');
class Model_page2 extends Model
{
	protected $sess_params;
	public function className()
	{
		return __CLASS__;
	}
	public function output()
	{
		$this->sess_params[] = "1";
		$this->sess_params[] = "2";
		$this->sess_params[] = "3";
		//echo $this->name;exit;
		$this->getCondAdapter();
	}
	public function getCondAdapter()
	{
		return CondAdapterFact::create();
	}
}
class CondAdapterFact
{
	public static function create()
	{
		return new TestObject2();
	}
}
class TestObject2
{
	public function __construct()
	{
		$this->test2();
	}
	
	public function test2()
	{
		echo 'inside TestObject2 test function<hr>';
		print_r(Registry::ins()->get('model1'));
		print_r(Registry::ins()->get('model2'));
		exit;
		//print_r(RegisterGlobal::ins()->model->params);exit;
	}
}
?>