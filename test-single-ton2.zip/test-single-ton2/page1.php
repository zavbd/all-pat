<?php
require_once('models/Model_page1.php');
//require_once('models/Model_page2.php');
require_once('models/DownloadCsvVisitor.php');
$this_model1 = new Model_page1();
$this_model1->output();
$this_model1->acceptVisitor(new DownloadCsvVisitor());
/*Registry::ins()->set('model1', $this_model1);
$this_model2 = new Model_page2();
Registry::ins()->set('model2', $this_model2);
$this_model1->output();
$this_model2->output();
*/
?>