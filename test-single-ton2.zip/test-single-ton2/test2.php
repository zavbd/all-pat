<?php
class js_file1
{
	private static $instance;
	private $factory;
	private function __construct()
	{
	}
	public static function ins()
	{
		if(self::$instance==null)
		{
			echo 'initializing<hr>';
			self::$instance=new js_file1();
			self::$instance->factory=new JsFactory();
		}
		return self::$instance;
	}
	
	public function proc1()
	{
		
		$this->factory->print1();
		unset($this->factory);
		echo $this->proc2();
	}
	
	private function proc2()
	{
		return "this is process2<hr>";
	}
	
	public function __destruct()
	{
		echo __CLASS__.' this is destroyed<hr>';
		//unset($this->factory);
	}
}

class JsFactory
{
	public static function create()
	{
		return call_user_func(array("js_file1", "ins"));
	}
	
	public static function print1()
	{
		echo "this is from factory class<hr>";
	}
	
	public function __destruct()
	{
		echo __CLASS__.' this is destroyed<hr>';
	}
}
$obj1=JsFactory::create();
$obj1->proc1();
$obj2=JsFactory::create();
$obj2->proc1();
$obj3=JsFactory::create();
$obj3->proc1();
$obj4=JsFactory::create();
$obj4->proc1();
?>